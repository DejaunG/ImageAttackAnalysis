import tensorflow as tf
import matplotlib as mpl
import matplotlib.pyplot as plt
import os
import argparse

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

mpl.rcParams['figure.figsize'] = (8, 8)
mpl.rcParams['axes.grid'] = False

pretrained_model = tf.keras.applications.MobileNetV2(include_top=True,
                                                     weights='imagenet')
pretrained_model.trainable = False

decode_predictions = tf.keras.applications.mobilenet_v2.decode_predictions

def preprocess(image):
  image = tf.cast(image, tf.float32)
  image = tf.image.resize(image, (224, 224))
  image = image[..., :3]
  image = tf.keras.applications.mobilenet_v2.preprocess_input(image)
  image = image[None, ...]
  return image

def get_imagenet_label(probs):
  return decode_predictions(probs, top=1)[0][0]

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('image_path', type=str, help="pictures/UndercoverGPT.png")
args = parser.parse_args()

image_path = args.image_path
image_raw = tf.io.read_file(image_path)
image = tf.image.decode_image(image_raw)

image = preprocess(image)
image_probs = pretrained_model.predict(image)

loss_object = tf.keras.losses.CategoricalCrossentropy()

def create_adversarial_pattern(input_image, input_label):
  with tf.GradientTape() as tape:
    tape.watch(input_image)
    prediction = pretrained_model(input_image)
    loss = loss_object(input_label, prediction)

  gradient = tape.gradient(loss, input_image)
  signed_grad = tf.sign(gradient)
  return signed_grad

labrador_retriever_index = 208
label = tf.one_hot(labrador_retriever_index, image_probs.shape[-1])
label = tf.reshape(label, (1, image_probs.shape[-1]))

perturbations = create_adversarial_pattern(image, label)

def display_images(image, description, perturbations, epsilons):
    _, label, confidence = get_imagenet_label(pretrained_model.predict(image))
    print('{} \n {} : {:.2f}% Confidence'.format(description, label, confidence*100))
    fig, axes = plt.subplots(1, len(epsilons) + 3, figsize=(20, 20))
    fig.subplots_adjust(hspace=3.0, wspace=3.0)  # Adjust the spacing between subplots

    axes[0].imshow(image[0]*0.5+0.5)
    axes[0].set_title('{} \n {} : {:.2f}% Confidence'.format(description, label, confidence*100))
    fig.savefig('generatedimages/input_image.png')

    _, label, confidence = get_imagenet_label(pretrained_model.predict(image + perturbations))
    print('Raw Adversarial Image \n {} : {:.2f}% Confidence'.format('Original Image', label, confidence*100))
    axes[1].imshow(perturbations[0]*0.5+0.5)
    axes[1].set_title('Raw Adversarial Image')
    fig.savefig('generatedimages/raw_adversarial_image.png')

    adv_image = image + perturbations
    adv_image = tf.clip_by_value(adv_image, -1, 1)
    _, label, confidence = get_imagenet_label(pretrained_model.predict(adv_image))
    print('Adversarial Image \n {} : {:.2f}% Confidence'.format(label, confidence*100))
    axes[2].imshow(adv_image[0]*0.5+0.5)
    axes[2].set_title('{} \n {} : {:.2f}% Confidence'.format('Adversarial Image', label, confidence*100))
    fig.savefig('generatedimages/adversarial_image.png')

    for i, eps in enumerate(epsilons):
        adv_x = image + eps * perturbations
        adv_x = tf.clip_by_value(adv_x, -1, 1)
        _, label, confidence = get_imagenet_label(pretrained_model.predict(adv_x))
        print('Epsilon = {:0.3f} \n {} : {:.2f}% Confidence'.format(eps, label, confidence*100))
        axes[i+3].imshow(adv_x[0]*0.5+0.5)
        axes[i+3].set_title('{} \n {} : {:.2f}% Confidence'.format('Epsilon = {:0.3f}'.format(eps), label, confidence*100))
        fig.savefig('generatedimages/epsilon_{}.png'.format(i))
        plt.close(fig)

epsilons = [0, 0.01, 0.1, 0.15]
display_images(image, 'Input', perturbations, epsilons)